package net.mcreator.kerilom.immersivestamina.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.kerilom.immersivestamina.network.ImmersiveStaminaModVariables;

public class SetCooldownRegenProcedure {
	public static void execute(Entity entity, double value) {
		if (entity == null)
			return;
		if (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).cd_regen < value) {
			{
				entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
					capability.cd_regen = value;
					capability.markSyncDirty();
				});
			}
		}
	}
}