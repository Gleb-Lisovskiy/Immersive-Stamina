package net.mcreator.kerilom.immersivestamina.configuration;

import net.minecraftforge.common.ForgeConfigSpec;

public class ConfigConfiguration {
	public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
	public static final ForgeConfigSpec SPEC;
	public static final ForgeConfigSpec.ConfigValue<Boolean> ENABLE_SMOOTHSPRINTINGCOST;
	public static final ForgeConfigSpec.ConfigValue<Double> SETCDREGEN_SPRINT;
	public static final ForgeConfigSpec.ConfigValue<Double> COST_SPRINT;
	public static final ForgeConfigSpec.ConfigValue<Boolean> ENABLE_SPRINTING;
	public static final ForgeConfigSpec.ConfigValue<Double> SETCDREGEN_JUMP;
	public static final ForgeConfigSpec.ConfigValue<Double> COST_JUMP;
	public static final ForgeConfigSpec.ConfigValue<Boolean> ENABLE_JUMP;
	public static final ForgeConfigSpec.ConfigValue<Double> SETCDREGEN_SWING;
	public static final ForgeConfigSpec.ConfigValue<Double> COST_SWING;
	public static final ForgeConfigSpec.ConfigValue<Boolean> ENABLE_SWING;
	public static final ForgeConfigSpec.ConfigValue<Double> SETCDREGEN_BOW;
	public static final ForgeConfigSpec.ConfigValue<Double> COST_BOW;
	public static final ForgeConfigSpec.ConfigValue<Boolean> ENABLE_BOW;
	public static final ForgeConfigSpec.ConfigValue<Double> SETCDREGEN_DAMAGE;
	public static final ForgeConfigSpec.ConfigValue<Double> COST_DAMAGE;
	public static final ForgeConfigSpec.ConfigValue<Boolean> COST_DAMAGEMULTIPLIER;
	public static final ForgeConfigSpec.ConfigValue<Boolean> ENABLE_DAMAGE;
	public static final ForgeConfigSpec.ConfigValue<Double> SETCDREGEN_SHIELD;
	public static final ForgeConfigSpec.ConfigValue<Double> COST_SHIELD;
	public static final ForgeConfigSpec.ConfigValue<Boolean> ENABLE_SHIELD;
	public static final ForgeConfigSpec.ConfigValue<Double> SETAT_TIREDTRUE;
	public static final ForgeConfigSpec.ConfigValue<Double> SETAT_TIREDFALSE;
	public static final ForgeConfigSpec.ConfigValue<Boolean> ENABLE_SMOOTHREGEN;
	public static final ForgeConfigSpec.ConfigValue<Double> HUNGER;
	public static final ForgeConfigSpec.ConfigValue<Double> MAX_STAMINA;
	public static final ForgeConfigSpec.ConfigValue<Double> REGEN;
	public static final ForgeConfigSpec.ConfigValue<Double> REGENMOVING;
	static {
		BUILDER.push("Actions/Events");
		BUILDER.push("Sprinting");
		BUILDER.push("Smooth Cost");
		ENABLE_SMOOTHSPRINTINGCOST = BUILDER.comment("Enables Smooth Sprinting Cost").define("Enable", true);
		BUILDER.pop();
		SETCDREGEN_SPRINT = BUILDER.comment("Per Tick").define("Set Cooldown Regen", (double) 35);
		COST_SPRINT = BUILDER.comment("Per Tick").define("Cost", (double) 0.08);
		ENABLE_SPRINTING = BUILDER.comment("Enables Sprinting Cost").define("Enable", true);
		BUILDER.pop();
		BUILDER.push("Jump");
		SETCDREGEN_JUMP = BUILDER.comment("Per Tick").define("Set Cooldown Regen", (double) 60);
		COST_JUMP = BUILDER.comment("Per Jump").define("Cost", (double) 0.55);
		ENABLE_JUMP = BUILDER.comment("Enables Jump Cost").define("Enable", true);
		BUILDER.pop();
		BUILDER.push("Swing");
		SETCDREGEN_SWING = BUILDER.comment("Per Swing").define("Set Cooldown Regen", (double) 25);
		COST_SWING = BUILDER.comment("Per Swing").define("Cost", (double) 0.1);
		ENABLE_SWING = BUILDER.comment("Enables Swing Cost").define("Enable", true);
		BUILDER.pop();
		BUILDER.push("Bow Using");
		SETCDREGEN_BOW = BUILDER.comment("Per Tick").define("Set Cooldown Regen", (double) 9);
		COST_BOW = BUILDER.comment("Per Tick").define("Cost", (double) 0.08);
		ENABLE_BOW = BUILDER.comment("Enables Using Bow Cost").define("Enable", true);
		BUILDER.pop();
		BUILDER.push("Damage");
		SETCDREGEN_DAMAGE = BUILDER.comment("Every taking damage").define("Set Cooldown Regen", (double) 35);
		COST_DAMAGE = BUILDER.comment("Every taking damage").define("Cost", (double) 0.1);
		COST_DAMAGEMULTIPLIER = BUILDER.comment("Multipliers Cost Stamina").define("Damage Multiplier", true);
		ENABLE_DAMAGE = BUILDER.comment("Enables Shield Block Attack Cost").define("Enable", true);
		BUILDER.pop();
		BUILDER.push("Shield Block Attack");
		SETCDREGEN_SHIELD = BUILDER.comment("Every Block").define("Set Cooldown Regen", (double) 31);
		COST_SHIELD = BUILDER.comment("Every Block").define("Cost", (double) 0.08);
		ENABLE_SHIELD = BUILDER.comment("Enables Shield Block Attack Cost").define("Enable", true);
		BUILDER.pop();
		BUILDER.pop();
		BUILDER.push("Mechanics");
		BUILDER.push("Tired");
		BUILDER.push("True");
		SETAT_TIREDTRUE = BUILDER.comment("In percents").define("Set at", (double) 0);
		BUILDER.pop();
		BUILDER.push("False");
		SETAT_TIREDFALSE = BUILDER.comment("In percents").define("Set at", (double) 30);
		BUILDER.pop();
		BUILDER.pop();
		BUILDER.push("Smooth Regen");
		ENABLE_SMOOTHREGEN = BUILDER.comment("Enables Smooth Regen").define("Enable", true);
		BUILDER.pop();
		BUILDER.pop();
		BUILDER.push("Hunger");
		HUNGER = BUILDER.comment("In percents").define("Set at", (double) 30);
		BUILDER.pop();
		BUILDER.push("Thirst");
		BUILDER.push("Legendary Survival Overhaul");

		BUILDER.pop();
		BUILDER.push("Thirst Was Taken");

		BUILDER.pop();
		BUILDER.push("Tough As Nail");

		BUILDER.pop();
		BUILDER.pop();
		MAX_STAMINA = BUILDER.comment("Sets Player Max Stamina").define("Max Stamina", (double) 20);
		REGEN = BUILDER.comment("Per Tick").define("Regen", (double) 0.05);
		REGENMOVING = BUILDER.comment("Per Tick").define("Regen When Moving", (double) 0.015);

		SPEC = BUILDER.build();
	}

}