package net.mcreator.kerilom.immersivestamina.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.level.GameType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.Minecraft;

import net.mcreator.kerilom.immersivestamina.network.ImmersiveStaminaModVariables;
import net.mcreator.kerilom.immersivestamina.init.ImmersiveStaminaModAttributes;
import net.mcreator.kerilom.immersivestamina.configuration.ConfigConfiguration;

import javax.annotation.Nullable;

import java.util.UUID;

@Mod.EventBusSubscriber
public class CoreProcedure {
	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			execute(event, event.player);
		}
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (!(getEntityGameType(entity) == GameType.CREATIVE || getEntityGameType(entity) == GameType.SPECTATOR)) {
			if (!entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).disablecoststamina) {
				if (ConfigConfiguration.ENABLE_SWING.get() && !entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).disablecostswing) {
					if (IsPlayerSwingingProcedure.execute(entity)) {
						if (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).stamina > 0) {
							SetCooldownRegenProcedure.execute(entity,
									(double) ConfigConfiguration.SETCDREGEN_SWING.get()
											* (entity instanceof LivingEntity _livingEntity4 && _livingEntity4.getAttributes().hasAttribute(ImmersiveStaminaModAttributes.REGEN_COOLDOWN_STAMINA_MULTIPLIER.get())
													? _livingEntity4.getAttribute(ImmersiveStaminaModAttributes.REGEN_COOLDOWN_STAMINA_MULTIPLIER.get()).getValue()
													: 0));
							{
								entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
									capability.stamina = entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).stamina - (double) ConfigConfiguration.COST_SWING.get()
											* (entity instanceof LivingEntity _livingEntity6 && _livingEntity6.getAttributes().hasAttribute(ImmersiveStaminaModAttributes.SWING_COST_STAMINA_MULTIPLIER.get())
													? _livingEntity6.getAttribute(ImmersiveStaminaModAttributes.SWING_COST_STAMINA_MULTIPLIER.get()).getValue()
													: 0);
									capability.markSyncDirty();
								});
							}
						}
						if (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).stamina > (double) ConfigConfiguration.MAX_STAMINA.get()) {
							{
								entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
									capability.stamina = (double) ConfigConfiguration.MAX_STAMINA.get();
									capability.markSyncDirty();
								});
							}
						}
						if (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).regencdtomultiplier > 0) {
							{
								entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
									capability.regencdtomultiplier = entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).regencdtomultiplier - 0.02;
									capability.markSyncDirty();
								});
							}
						}
					}
				}
				if (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).usingItem.getItem() instanceof BowItem) {
					if (ConfigConfiguration.ENABLE_BOW.get() && !entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).disablecostbow) {
						if (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).stamina > 0) {
							SetCooldownRegenProcedure.execute(entity,
									(double) ConfigConfiguration.SETCDREGEN_BOW.get()
											* (entity instanceof LivingEntity _livingEntity12 && _livingEntity12.getAttributes().hasAttribute(ImmersiveStaminaModAttributes.REGEN_COOLDOWN_STAMINA_MULTIPLIER.get())
													? _livingEntity12.getAttribute(ImmersiveStaminaModAttributes.REGEN_COOLDOWN_STAMINA_MULTIPLIER.get()).getValue()
													: 0));
							{
								entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
									capability.stamina = entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).stamina
											- 0.05 * (entity instanceof LivingEntity _livingEntity13 && _livingEntity13.getAttributes().hasAttribute(ImmersiveStaminaModAttributes.BOW_COST_STAMINA_MULTIPLIER.get())
													? _livingEntity13.getAttribute(ImmersiveStaminaModAttributes.BOW_COST_STAMINA_MULTIPLIER.get()).getValue()
													: 0);
									capability.markSyncDirty();
								});
							}
						}
					}
				}
			}
			if (!(entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).usingItem
					.getItem() == (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem())
					&& (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).usingItemSlot).equals("main")) {
				{
					entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
						capability.usingItem = ItemStack.EMPTY.copy();
						capability.markSyncDirty();
					});
				}
			}
			if (!(entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).usingItem
					.getItem() == (entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem())
					&& (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).usingItemSlot).equals("off")) {
				{
					entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
						capability.usingItem = ItemStack.EMPTY.copy();
						capability.markSyncDirty();
					});
				}
			}
			if (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).usingItem.getItem() == ItemStack.EMPTY.getItem()
					&& !(entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).usingItemSlot).equals("None")) {
				{
					entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
						capability.usingItemSlot = "None";
						capability.markSyncDirty();
					});
				}
			}
			if (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).stamina < 0) {
				{
					entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
						capability.stamina = 0;
						capability.markSyncDirty();
					});
				}
			}
			if (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).cd_regen < 0) {
				{
					entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
						capability.cd_regen = 0;
						capability.markSyncDirty();
					});
				}
			}
			if (ConfigConfiguration.ENABLE_SMOOTHREGEN.get()) {
				if (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).regencdtomultiplier < 1
						&& entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).cd_regen <= 0) {
					{
						entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
							capability.regencdtomultiplier = entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).regencdtomultiplier + 0.01;
							capability.markSyncDirty();
						});
					}
				}
				if (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).regencdtomultiplier > 0
						&& entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).cd_regen > 0) {
					{
						entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
							capability.regencdtomultiplier = entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).regencdtomultiplier - 0.02;
							capability.markSyncDirty();
						});
					}
				}
				if (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).regencdtomultiplier < 0) {
					{
						entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
							capability.regencdtomultiplier = 0;
							capability.markSyncDirty();
						});
					}
				}
				if (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).regencdtomultiplier > 1) {
					{
						entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
							capability.regencdtomultiplier = 1;
							capability.markSyncDirty();
						});
					}
				}
			} else {
				if (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).regencdtomultiplier < 1
						&& entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).cd_regen <= 0) {
					{
						entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
							capability.regencdtomultiplier = 1;
							capability.markSyncDirty();
						});
					}
				}
				if (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).regencdtomultiplier > 0
						&& entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).cd_regen > 0) {
					{
						entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
							capability.regencdtomultiplier = 0;
							capability.markSyncDirty();
						});
					}
				}
			}
			if (ConfigConfiguration.ENABLE_SMOOTHSPRINTINGCOST.get()) {
				if (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).sprinttomultiplier > 1) {
					{
						entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
							capability.sprinttomultiplier = 1;
							capability.markSyncDirty();
						});
					}
				}
				if (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).sprinttomultiplier < 0) {
					{
						entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
							capability.sprinttomultiplier = 0;
							capability.markSyncDirty();
						});
					}
				}
				if (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).cd_regen <= 0
						&& entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).sprinttomultiplier > 0) {
					{
						entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
							capability.sprinttomultiplier = entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).sprinttomultiplier - 0.02;
							capability.markSyncDirty();
						});
					}
				}
			}
			if (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).cd_regen > 0
					&& GetPercentFromValueProcedure.execute(entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).stamina, (double) ConfigConfiguration.MAX_STAMINA.get()) <= 0
					&& entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).tired == false) {
				if (entity instanceof LivingEntity _entity) {
					AttributeModifier modifier = new AttributeModifier(UUID.fromString("237e7346-8953-349b-b805-f42b3848daa1"), "immersive_stamina:tired", (-0.65), AttributeModifier.Operation.MULTIPLY_TOTAL);
					if (!_entity.getAttribute(Attributes.MOVEMENT_SPEED).hasModifier(modifier)) {
						_entity.getAttribute(Attributes.MOVEMENT_SPEED).addPermanentModifier(modifier);
					}
				}
				if (entity instanceof LivingEntity _entity) {
					AttributeModifier modifier = new AttributeModifier(UUID.fromString("237e7346-8953-349b-b805-f42b3848daa1"), "immersive_stamina:tired", (-0.4), AttributeModifier.Operation.MULTIPLY_TOTAL);
					if (!_entity.getAttribute(ImmersiveStaminaModAttributes.REGEN_STAMINA_MULTIPLIER.get()).hasModifier(modifier)) {
						_entity.getAttribute(ImmersiveStaminaModAttributes.REGEN_STAMINA_MULTIPLIER.get()).addPermanentModifier(modifier);
					}
				}
				if (entity instanceof LivingEntity _entity) {
					AttributeModifier modifier = new AttributeModifier(UUID.fromString("237e7346-8953-349b-b805-f42b3848daa1"), "immersive_stamina:tired", 0.4, AttributeModifier.Operation.MULTIPLY_TOTAL);
					if (!_entity.getAttribute(ImmersiveStaminaModAttributes.REGEN_COOLDOWN_STAMINA_MULTIPLIER.get()).hasModifier(modifier)) {
						_entity.getAttribute(ImmersiveStaminaModAttributes.REGEN_COOLDOWN_STAMINA_MULTIPLIER.get()).addPermanentModifier(modifier);
					}
				}
				if (entity instanceof LivingEntity _entity) {
					AttributeModifier modifier = new AttributeModifier(UUID.fromString("237e7346-8953-349b-b805-f42b3848daa1"), "immersive_stamina:tired", (-0.7), AttributeModifier.Operation.MULTIPLY_TOTAL);
					if (!_entity.getAttribute(Attributes.ATTACK_SPEED).hasModifier(modifier)) {
						_entity.getAttribute(Attributes.ATTACK_SPEED).addPermanentModifier(modifier);
					}
				}
				{
					entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
						capability.tired = true;
						capability.markSyncDirty();
					});
				}
			}
			if (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).tired == true) {
				entity.setSprinting(false);
			}
			if (entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).cd_regen <= 0 && GetPercentFromValueProcedure
					.execute(entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).stamina, (double) ConfigConfiguration.MAX_STAMINA.get()) >= 30
					&& entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).orElseGet(ImmersiveStaminaModVariables.PlayerVariables::new).tired == true) {
				if (entity instanceof LivingEntity _entity) {
					_entity.getAttribute(Attributes.MOVEMENT_SPEED).removeModifier(UUID.fromString("237e7346-8953-349b-b805-f42b3848daa1"));
				}
				if (entity instanceof LivingEntity _entity) {
					_entity.getAttribute(ImmersiveStaminaModAttributes.REGEN_STAMINA_MULTIPLIER.get()).removeModifier(UUID.fromString("237e7346-8953-349b-b805-f42b3848daa1"));
				}
				if (entity instanceof LivingEntity _entity) {
					_entity.getAttribute(ImmersiveStaminaModAttributes.REGEN_COOLDOWN_STAMINA_MULTIPLIER.get()).removeModifier(UUID.fromString("237e7346-8953-349b-b805-f42b3848daa1"));
				}
				if (entity instanceof LivingEntity _entity) {
					_entity.getAttribute(Attributes.ATTACK_SPEED).removeModifier(UUID.fromString("237e7346-8953-349b-b805-f42b3848daa1"));
				}
				{
					entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
						capability.tired = false;
						capability.markSyncDirty();
					});
				}
			}
			RegenTickProcedure.execute(entity);
			SprintTickProcedure.execute(entity);
		}
		{
			entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
				capability.memorypos = entity.position();
				capability.markSyncDirty();
			});
		}
	}

	private static GameType getEntityGameType(Entity entity) {
		if (entity instanceof ServerPlayer serverPlayer) {
			return serverPlayer.gameMode.getGameModeForPlayer();
		} else if (entity instanceof Player player && player.level().isClientSide()) {
			PlayerInfo playerInfo = Minecraft.getInstance().getConnection().getPlayerInfo(player.getGameProfile().getId());
			if (playerInfo != null)
				return playerInfo.getGameMode();
		}
		return null;
	}
}