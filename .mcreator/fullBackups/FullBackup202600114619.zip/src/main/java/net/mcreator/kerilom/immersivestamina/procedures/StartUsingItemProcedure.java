package net.mcreator.kerilom.immersivestamina.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.kerilom.immersivestamina.network.ImmersiveStaminaModVariables;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class StartUsingItemProcedure {
	@SubscribeEvent
	public static void onUseItemStart(LivingEntityUseItemEvent.Start event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity(), event.getItem());
		}
	}

	public static void execute(Entity entity, ItemStack itemstack) {
		execute(null, entity, itemstack);
	}

	private static void execute(@Nullable Event event, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == itemstack.getItem()) {
			{
				entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
					capability.usingItemSlot = "main";
					capability.markSyncDirty();
				});
			}
		} else if ((entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem() == itemstack.getItem()) {
			{
				entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
					capability.usingItemSlot = "off";
					capability.markSyncDirty();
				});
			}
		} else {
			{
				entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
					capability.usingItemSlot = "custom";
					capability.markSyncDirty();
				});
			}
		}
		{
			entity.getCapability(ImmersiveStaminaModVariables.PLAYER_VARIABLES).ifPresent(capability -> {
				capability.usingItem = itemstack.copy();
				capability.markSyncDirty();
			});
		}
	}
}